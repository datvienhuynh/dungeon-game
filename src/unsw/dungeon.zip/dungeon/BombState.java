package unsw.dungeon;

public interface BombState {
	
	public void lit();

}
