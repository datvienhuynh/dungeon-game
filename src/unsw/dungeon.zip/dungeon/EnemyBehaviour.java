package unsw.dungeon;

public interface EnemyBehaviour {
	
	public void move(Dungeon dungeon);
	
}
